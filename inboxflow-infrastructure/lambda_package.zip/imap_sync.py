import imaplib
import os

def lambda_handler(event, context):
    # Get values from environment variables (or use defaults)
    EMAIL_SERVER = "imap.mail.yahoo.com"
    EMAIL_USER = "stevenmcconnon@yahoo.com"
    EMAIL_PASSWORD = "bgmimovwilgmvdjj"  # app password

    try:
        # Connect using IMAP over SSL on port 993
        mail = imaplib.IMAP4_SSL(EMAIL_SERVER, 993)
        mail.login(EMAIL_USER, EMAIL_PASSWORD)
        print("Logged in successfully!")
        mail.logout()
        return {
            "statusCode": 200,
            "body": "Logged in successfully!"
        }
    except Exception as e:
        print("Error:", e)
        return {
            "statusCode": 500,
            "body": f"Error: {str(e)}"
        }